# NEO PADS1: Website Project

A five-page website for NEO PADS1, a Pretoria NGO fighting period poverty.
Pages: Home, About, Programmes (`services.html`), Enquire, Contact.

## How to run
The programme list and enquiry form load `data/programmes.json` with `fetch()`,
so open the site through a server, not by double-clicking the files.
Use the VS Code **Live Server** extension, or run `python -m http.server` in this folder.

## Deploying (free platform)
**Netlify:** go to app.netlify.com/drop and drag the whole project folder onto the page.
**GitHub Pages:** push the repository, then Settings > Pages > Deploy from branch `main` / root.
After deploying, replace `https://neopads1.netlify.app` in every `.html` file,
`sitemap.xml` and `robots.txt` with your real address.

## Things to replace with real details
- Phone, street address and the home page statistics (still placeholders from Part 2).
- Social media links in the footer (`facebook.com/neopads1` etc. are examples).
- Costs, places left and start dates in `data/programmes.json` (example figures).
- Pin positions on the contact map (approximate).

## Keyword research (Part 3, SEO)
| Page | Main keywords |
|------|---------------|
| Home | period poverty Pretoria, free sanitary pads, dignity workshops |
| About | period poverty NGO, Pretoria non-profit, menstrual dignity |
| Programmes | sanitary pad distribution, dignity workshops, sponsor a school |
| Enquire | volunteer Pretoria, donate sanitary pads, partner with NGO |
| Contact | contact NEO PADS1, NGO Sunnyside Pretoria |

## Changelog

### Part 2 feedback corrections
_Add one entry per change you make from your Part 2 feedback (date, file, what changed, why)._

### Part 3: Functionality and SEO
**JavaScript: interactive elements** (`assets/js/script.js`, `assets/css/style.css`)
- Added an accessible FAQ **accordion** on `about.html` (one open at a time, `aria-expanded`).
- Added a **gallery with lightbox** on `about.html` (click to enlarge, Esc/arrow keys, focus returns to the thumbnail).
- Added an **interactive Leaflet/OpenStreetMap map** on `contact.html` with markers and a "fly to" list; kept the Google Map below it.
- Added **animations**: scroll fade-in, card hover lift, count-up statistics on the home page (all disabled for `prefers-reduced-motion`).
- Used DOM manipulation (`createElement`, no `innerHTML`) to build cards, the lightbox, errors and responses.

**JavaScript: dynamic content**
- New `data/programmes.json`. `services.html` has a "Find a Programme" section whose cards are loaded with `fetch()`.
- Added **search, category filter and sort** (name, cost, places left) with a live result count.
- "Enquire about this" buttons link to `enquire.html?programme=...` and preselect the programme.

**Forms** (`enquire.html`, `contact.html`)
- Rebuilt both forms with input, select, number, date, tel and textarea elements, HTML5 attributes and `action` attributes.
- JavaScript validation: name, email, SA phone format, date range (not in the past, within 12 months), message length with a live character counter, inline error messages and focus on the first error.
- `enquire.html`: after validation, an AJAX request loads programme data and shows cost, availability and earliest start date without reloading.
- `contact.html`: compiles the details into an email addressed to `RECIPIENT` (top of `script.js`) with a preview and a "Send this email" button.
- Removed the old demo-only form handler and the `data-demo-form` attribute.

**SEO**
- New unique title tags and meta descriptions, keywords, canonical links, Open Graph and Twitter tags on every page.
- Added `robots.txt`, `sitemap.xml`, a `404.html` page and schema.org `NGO` JSON-LD (local SEO) on the home page.
- Added contextual internal links between pages and descriptive alt text on all new images.
- Added social media links in the footer.

**Performance and security**
- Scripts use `defer`; added `preconnect` for fonts; `loading="lazy"` and `decoding="async"` on below-the-fold images.
- Added a Content-Security-Policy meta tag, a `_headers` file (nosniff, frame, referrer, HSTS, caching) and `rel="noopener noreferrer"` on external links.
