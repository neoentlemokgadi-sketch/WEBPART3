/* ============================================================
   NEO PADS1 WEBSITE SCRIPT
   This file adds a bit of interactivity to the website.
   It waits until the whole page has loaded, then runs.
   ============================================================ */

document.addEventListener("DOMContentLoaded", function () {
  /* --------------------------------------------------------
     1. MOBILE NAVIGATION TOGGLE
     On small screens the menu is hidden. When someone clicks
     the hamburger button, we add/remove the "is-open" class,
     which the CSS uses to show or hide the menu.
     -------------------------------------------------------- */
  var navToggle = document.querySelector(".nav-toggle");
  var navMenu = document.querySelector(".nav-menu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", function () {
      // toggle() switches the class on and off each time we click
      navMenu.classList.toggle("is-open");

      // update aria-expanded so screen readers know if the menu is open
      var isOpen = navMenu.classList.contains("is-open");
      navToggle.setAttribute("aria-expanded", isOpen);
    });

    // close the mobile menu automatically once a link is clicked
    var navLinks = navMenu.querySelectorAll("a");
    navLinks.forEach(function (link) {
      link.addEventListener("click", function () {
        navMenu.classList.remove("is-open");
      });
    });
  }

  /* --------------------------------------------------------
     2. HIGHLIGHT THE CURRENT PAGE IN THE NAVIGATION MENU
     We compare the current page's file name to each link's
     "href" and add the "active" class when they match.
     -------------------------------------------------------- */
  var currentPage = window.location.pathname.split("/").pop() || "index.html";
  var allNavLinks = document.querySelectorAll(".nav-menu a");

  allNavLinks.forEach(function (link) {
    var linkPage = link.getAttribute("href");
    if (linkPage === currentPage) {
      link.classList.add("active");
    }
  });

  /* --------------------------------------------------------
     3. SHARED HELPERS
     Small reusable functions used by the features below.
     -------------------------------------------------------- */
  var RECIPIENT = "info@neopads1.org"; // the contact form email is addressed to this person
  var motionOK = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // make("p", {class: "x"}, "text") builds an element safely (no innerHTML)
  function make(tag, attrs, text) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (key) { node.setAttribute(key, attrs[key]); });
    }
    if (text !== undefined) { node.textContent = text; }
    return node;
  }
  function money(n) { return "R" + Number(n).toLocaleString("en-ZA"); }
  function prettyDate(d) {
    return d.toLocaleDateString("en-ZA", { day: "numeric", month: "long", year: "numeric" });
  }
  // AJAX: fetches the programme data file without reloading the page
  function loadProgrammes() {
    return fetch("data/programmes.json").then(function (res) {
      if (!res.ok) { throw new Error("HTTP " + res.status); }
      return res.json();
    });
  }

  /* --------------------------------------------------------
     4. SCROLL ANIMATIONS + ANIMATED COUNTERS
     Elements fade up as they scroll into view, and the stat
     numbers on the home page count up from zero.
     -------------------------------------------------------- */
  function countUp(node) {
    var target = parseInt(node.getAttribute("data-count"), 10);
    var suffix = node.getAttribute("data-suffix") || "";
    if (!motionOK) { node.textContent = target.toLocaleString("en-ZA") + suffix; return; }
    var startTime = null;
    function step(now) {
      if (!startTime) { startTime = now; }
      var progress = Math.min((now - startTime) / 1400, 1);
      var eased = 1 - Math.pow(1 - progress, 3); // slows down towards the end
      node.textContent = Math.round(target * eased).toLocaleString("en-ZA") + suffix;
      if (progress < 1) { requestAnimationFrame(step); }
    }
    requestAnimationFrame(step);
  }

  if ("IntersectionObserver" in window) {
    document.documentElement.classList.add("js-reveal");
    var revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) { return; }
        entry.target.classList.add("is-visible");
        if (entry.target.hasAttribute("data-count")) { countUp(entry.target); }
        revealObserver.unobserve(entry.target);
      });
    }, { threshold: 0.15 });

    document.querySelectorAll(".card, .stats > div, .split-section, .accordion, .gallery-item, [data-count]")
      .forEach(function (node, i) {
        if (!node.hasAttribute("data-count")) {
          node.classList.add("reveal");
          node.style.transitionDelay = (i % 3) * 80 + "ms"; // small stagger
        }
        revealObserver.observe(node);
      });
  }

  /* --------------------------------------------------------
     5. ACCORDION (FAQ on the About page)
     Click a question to open its answer; opening one closes
     the others. aria-expanded keeps it screen-reader friendly.
     -------------------------------------------------------- */
  document.querySelectorAll(".accordion-trigger").forEach(function (trigger) {
    trigger.addEventListener("click", function () {
      var wasOpen = trigger.getAttribute("aria-expanded") === "true";
      var accordion = trigger.closest(".accordion");
      accordion.querySelectorAll(".accordion-trigger").forEach(function (other) {
        other.setAttribute("aria-expanded", "false");
        document.getElementById(other.getAttribute("aria-controls")).classList.remove("is-open");
      });
      if (!wasOpen) {
        trigger.setAttribute("aria-expanded", "true");
        document.getElementById(trigger.getAttribute("aria-controls")).classList.add("is-open");
      }
    });
  });

  /* --------------------------------------------------------
     6. GALLERY WITH LIGHTBOX (About page)
     Clicking a picture opens it large in a dialog. Works with
     the Esc key, the arrow keys and the on-screen buttons.
     -------------------------------------------------------- */
  var galleryItems = Array.prototype.slice.call(document.querySelectorAll(".gallery-item"));
  if (galleryItems.length) {
    var current = 0;
    var opener = null;
    var lightbox = make("div", { class: "lightbox", role: "dialog", "aria-modal": "true", "aria-label": "Image viewer", hidden: "" });
    var lbImage = make("img", { alt: "" });
    var lbCaption = make("p", { class: "lightbox-caption" });
    var lbClose = make("button", { class: "lightbox-btn lightbox-close", type: "button", "aria-label": "Close image viewer" }, "\u00d7");
    var lbPrev = make("button", { class: "lightbox-btn lightbox-prev", type: "button", "aria-label": "Previous image" }, "\u2039");
    var lbNext = make("button", { class: "lightbox-btn lightbox-next", type: "button", "aria-label": "Next image" }, "\u203a");
    [lbClose, lbPrev, lbNext, lbImage, lbCaption].forEach(function (n) { lightbox.appendChild(n); });
    document.body.appendChild(lightbox);

    function showImage(index) {
      current = (index + galleryItems.length) % galleryItems.length;
      var img = galleryItems[current].querySelector("img");
      var caption = galleryItems[current].querySelector("figcaption");
      lbImage.src = img.getAttribute("src");
      lbImage.alt = img.getAttribute("alt");
      lbCaption.textContent = caption ? caption.textContent : "";
    }
    function openLightbox(index) {
      opener = document.activeElement;
      showImage(index);
      lightbox.hidden = false;
      document.body.classList.add("no-scroll");
      lbClose.focus();
    }
    function closeLightbox() {
      lightbox.hidden = true;
      document.body.classList.remove("no-scroll");
      if (opener) { opener.focus(); }
    }
    galleryItems.forEach(function (item, i) {
      item.querySelector("button").addEventListener("click", function () { openLightbox(i); });
    });
    lbClose.addEventListener("click", closeLightbox);
    lbPrev.addEventListener("click", function () { showImage(current - 1); });
    lbNext.addEventListener("click", function () { showImage(current + 1); });
    lightbox.addEventListener("click", function (e) { if (e.target === lightbox) { closeLightbox(); } });
    document.addEventListener("keydown", function (e) {
      if (lightbox.hidden) { return; }
      if (e.key === "Escape") { closeLightbox(); }
      if (e.key === "ArrowLeft") { showImage(current - 1); }
      if (e.key === "ArrowRight") { showImage(current + 1); }
    });
  }

  /* --------------------------------------------------------
     7. INTERACTIVE MAP (Contact page, Leaflet + OpenStreetMap)
     Markers for our office and donation-drive areas, plus a
     list beside the map that flies to the chosen place.
     -------------------------------------------------------- */
  var mapBox = document.getElementById("map");
  if (mapBox) {
    var places = [
      { name: "NEO PADS1 office", type: "Head office", lat: -25.7508, lng: 28.2108, note: "123 Jacaranda Street, Sunnyside. Mon to Fri, 08:00 to 16:00." },
      { name: "Hatfield donation drive", type: "Quarterly drive area", lat: -25.7487, lng: 28.2380, note: "Drop off pads and donations at our quarterly drive." },
      { name: "Menlyn donation drive", type: "Quarterly drive area", lat: -25.7826, lng: 28.2764, note: "Drop off pads and donations at our quarterly drive." },
      { name: "Centurion donation drive", type: "Quarterly drive area", lat: -25.8603, lng: 28.1894, note: "Drop off pads and donations at our quarterly drive." }
    ];
    var placeList = document.getElementById("location-list");

    if (window.L) {
      var map = L.map(mapBox, { scrollWheelZoom: false }).setView([-25.78, 28.23], 11);
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "&copy; OpenStreetMap contributors"
      }).addTo(map);

      places.forEach(function (place) {
        var popup = make("div");
        popup.appendChild(make("strong", null, place.name));
        popup.appendChild(make("br"));
        popup.appendChild(document.createTextNode(place.note));
        var icon = L.divIcon({ className: "map-pin", html: "<span></span>", iconSize: [28, 28], iconAnchor: [14, 28], popupAnchor: [0, -26] });
        place.marker = L.marker([place.lat, place.lng], { icon: icon, title: place.name }).addTo(map).bindPopup(popup);

        if (placeList) {
          var item = make("li");
          var button = make("button", { type: "button", class: "location-btn" });
          button.appendChild(make("strong", null, place.name));
          button.appendChild(make("span", null, place.type));
          button.addEventListener("click", function () {
            map.flyTo([place.lat, place.lng], 14, { animate: motionOK });
            place.marker.openPopup();
          });
          item.appendChild(button);
          placeList.appendChild(item);
        }
      });
    } else {
      mapBox.appendChild(make("p", { class: "map-fallback" }, "The interactive map could not load. Please use the Google map below."));
    }
  }

  /* --------------------------------------------------------
     8. DYNAMIC PROGRAMME LIST WITH SEARCH, FILTER AND SORT
     (Programmes page). The cards are built from the JSON file
     data/programmes.json, not typed into the HTML.
     -------------------------------------------------------- */
  var resultsBox = document.getElementById("programme-results");
  if (resultsBox) {
    var searchBox = document.getElementById("programme-search");
    var categoryBox = document.getElementById("programme-category");
    var sortBox = document.getElementById("programme-sort");
    var statusBox = document.getElementById("programme-status");
    var allProgrammes = [];

    var sorters = {
      name: function (a, b) { return a.name.localeCompare(b.name); },
      "cost-low": function (a, b) { return a.cost - b.cost; },
      "cost-high": function (a, b) { return b.cost - a.cost; },
      places: function (a, b) { return b.slotsLeft - a.slotsLeft; }
    };

    function buildCard(p) {
      var card = make("article", { class: "card programme-card" });
      card.appendChild(make("span", { class: "badge" }, p.category));
      card.appendChild(make("h3", null, p.name));
      card.appendChild(make("p", null, p.summary));
      var facts = make("ul", { class: "programme-facts" });
      facts.appendChild(make("li", null, "Cost: " + (p.cost === 0 ? "Free to join" : money(p.cost) + " per " + p.unit)));
      facts.appendChild(make("li", null, "Places left: " + p.slotsLeft));
      facts.appendChild(make("li", null, "Where: " + p.area));
      card.appendChild(facts);
      card.appendChild(make("a", { href: "enquire.html?programme=" + encodeURIComponent(p.id), class: "btn btn-secondary" }, "Enquire about this"));
      return card;
    }

    function renderProgrammes() {
      var term = searchBox.value.trim().toLowerCase();
      var matches = allProgrammes.filter(function (p) {
        var categoryOk = categoryBox.value === "all" || p.category === categoryBox.value;
        var text = (p.name + " " + p.summary + " " + p.area + " " + p.category).toLowerCase();
        return categoryOk && (term === "" || text.indexOf(term) !== -1);
      });
      matches.sort(sorters[sortBox.value]);

      resultsBox.textContent = "";
      matches.forEach(function (p) { resultsBox.appendChild(buildCard(p)); });
      if (!matches.length) {
        resultsBox.appendChild(make("p", { class: "no-results" }, "No programmes match your search. Try a different word or choose \u201cAll categories\u201d."));
      }
      statusBox.textContent = matches.length + (matches.length === 1 ? " programme found" : " programmes found");
    }

    loadProgrammes().then(function (list) {
      allProgrammes = list;
      list.map(function (p) { return p.category; })
        .filter(function (c, i, arr) { return arr.indexOf(c) === i; })
        .forEach(function (c) { categoryBox.appendChild(make("option", { value: c }, c)); });
      [searchBox, categoryBox, sortBox].forEach(function (control) {
        control.addEventListener("input", renderProgrammes);
      });
      renderProgrammes();
    }).catch(function () {
      resultsBox.textContent = "";
      resultsBox.appendChild(make("p", { class: "no-results" }, "Sorry, we could not load the programme list. If you opened this file directly, please run it through a local server (for example VS Code Live Server) or view the live site."));
    });
  }

  /* --------------------------------------------------------
     9. FORM VALIDATION TOOLKIT
     Each form gets a "rules" object: one function per field
     that returns an error message, or "" when the value is OK.
     Errors show under the field and the first bad field gets
     focus. HTML5 attributes (required, maxlength, type) are
     still in the HTML as a fallback if JavaScript is off.
     -------------------------------------------------------- */
  function nameError(v) {
    if (!v) { return "Please enter your full name."; }
    if (v.length < 2 || v.length > 60) { return "Your name must be between 2 and 60 characters."; }
    if (!/^[A-Za-z\u00C0-\u00FF' -]+$/.test(v)) { return "Names can only contain letters, spaces, hyphens and apostrophes."; }
    return "";
  }
  function emailError(v) {
    if (!v) { return "Please enter your email address."; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) { return "Please enter a valid email address, like name@example.com."; }
    return "";
  }
  function phoneError(v) {
    if (!v) { return ""; } // phone is optional
    if (!/^(\+27|0)[1-9]\d{8}$/.test(v.replace(/[\s-]/g, ""))) { return "Please enter a valid South African number, e.g. 082 123 4567."; }
    return "";
  }
  function dateError(v) {
    if (!v) { return ""; } // date is optional
    var chosen = new Date(v + "T00:00:00");
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var limit = new Date(today);
    limit.setFullYear(limit.getFullYear() + 1);
    if (isNaN(chosen.getTime())) { return "Please enter a valid date."; }
    if (chosen < today) { return "Your preferred start date can't be in the past."; }
    if (chosen > limit) { return "Please choose a date within the next 12 months."; }
    return "";
  }
  function messageError(v, min, max) {
    if (!v) { return "Please type a message."; }
    if (v.length < min) { return "Your message is too short. Please write at least " + min + " characters (you have " + v.length + ")."; }
    if (v.length > max) { return "Your message is too long. The limit is " + max + " characters."; }
    return "";
  }
  function requiredChoice(text) {
    return function (v) { return v ? "" : text; };
  }

  function showError(field, message) {
    var id = field.id + "-error";
    var box = document.getElementById(id);
    if (!box) {
      box = make("span", { id: id, class: "field-error", role: "alert" });
      field.parentNode.appendChild(box);
    }
    box.textContent = message;
    field.setAttribute("aria-invalid", message ? "true" : "false");
    field.setAttribute("aria-describedby", id);
    field.classList.toggle("is-invalid", !!message);
  }
  function clearErrors(form) {
    Array.prototype.forEach.call(form.elements, function (f) { if (f.id) { showError(f, ""); } });
  }
  function addCounter(area) {
    var counter = make("small", { class: "char-count", id: area.id + "-count" });
    area.parentNode.appendChild(counter);
    function update() { counter.textContent = area.value.length + " / " + area.maxLength + " characters"; }
    area.addEventListener("input", update);
    update();
  }
  function setupForm(form, rules, onValid) {
    form.noValidate = true; // we show our own friendlier messages
    var names = Object.keys(rules);
    function check(name) {
      var field = form.elements[name];
      var message = rules[name](field.value.trim(), form);
      showError(field, message);
      return message === "";
    }
    names.forEach(function (name) {
      var field = form.elements[name];
      field.addEventListener("blur", function () { check(name); });
      field.addEventListener("input", function () {
        if (field.getAttribute("aria-invalid") === "true") { check(name); }
      });
    });
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var firstBad = null;
      names.forEach(function (name) {
        if (!check(name) && !firstBad) { firstBad = form.elements[name]; }
      });
      if (firstBad) { firstBad.focus(); return; }
      onValid(form);
    });
  }

  /* --------------------------------------------------------
     10. ENQUIRY FORM (enquire.html)
     After validation we fetch the programme data (AJAX) and
     show the visitor an instant answer about cost and
     availability, without reloading the page.
     -------------------------------------------------------- */
  var enquiryForm = document.getElementById("enquiry-form");
  if (enquiryForm) {
    var programmeSelect = enquiryForm.elements.programme;
    var quantityGroup = document.getElementById("quantity-group");
    var enquiryResponse = document.getElementById("enquiry-response");
    var enquiryButton = enquiryForm.querySelector("button[type='submit']");

    var todayIso = new Date();
    todayIso.setMinutes(todayIso.getMinutes() - todayIso.getTimezoneOffset());
    enquiryForm.elements.startDate.min = todayIso.toISOString().slice(0, 10);
    addCounter(enquiryForm.elements.message);

    loadProgrammes().then(function (list) {
      list.forEach(function (p) { programmeSelect.appendChild(make("option", { value: p.id }, p.name)); });
      var wanted = new URLSearchParams(window.location.search).get("programme");
      if (wanted) { programmeSelect.value = wanted; } // set by the "Enquire about this" buttons
    }).catch(function () {
      programmeSelect.appendChild(make("option", { value: "" }, "Programmes could not load. Please try again later."));
    });

    // volunteers don't need to enter a quantity, so we hide that field for them
    enquiryForm.elements.reason.addEventListener("change", function () {
      var isVolunteer = enquiryForm.elements.reason.value === "volunteer";
      quantityGroup.hidden = isVolunteer;
      if (isVolunteer) { enquiryForm.elements.quantity.value = 1; showError(enquiryForm.elements.quantity, ""); }
    });

    var enquiryRules = {
      fullName: nameError,
      email: emailError,
      phone: phoneError,
      reason: requiredChoice("Please choose what you are interested in."),
      programme: requiredChoice("Please choose a programme."),
      quantity: function (v, form) {
        if (form.elements.reason.value === "volunteer") { return ""; }
        var n = Number(v);
        if (!v) { return "Please enter a number."; }
        if (!Number.isInteger(n) || n < 1 || n > 1000) { return "Please enter a whole number between 1 and 1000."; }
        return "";
      },
      startDate: dateError,
      message: function (v) { return messageError(v, 10, 500); }
    };

    setupForm(enquiryForm, enquiryRules, function (form) {
      enquiryButton.disabled = true;
      enquiryButton.textContent = "Checking availability\u2026";

      loadProgrammes().then(function (list) {
        var p = list.filter(function (item) { return item.id === form.elements.programme.value; })[0];
        showEnquiryResponse(form, p);
      }).catch(function () {
        enquiryResponse.textContent = "";
        enquiryResponse.appendChild(make("p", null, "Sorry, we couldn't check availability right now. Please try again, or email " + RECIPIENT + "."));
        enquiryResponse.hidden = false;
      }).then(function () {
        enquiryButton.disabled = false;
        enquiryButton.textContent = "Submit Enquiry";
      });
    });

    function showEnquiryResponse(form, p) {
      var reason = form.elements.reason.value;
      var qty = reason === "volunteer" ? 1 : Number(form.elements.quantity.value);
      var firstName = form.elements.fullName.value.trim().split(" ")[0];
      var preferred = form.elements.startDate.value ? new Date(form.elements.startDate.value + "T00:00:00") : null;
      var earliest = new Date(p.nextStart + "T00:00:00");
      var start = preferred && preferred > earliest ? preferred : earliest;
      var lines = [];

      if (reason === "volunteer") {
        lines.push("Cost: volunteering is free for you.");
        lines.push(p.volunteerSlots > 0
          ? "Availability: " + p.volunteerSlots + " volunteer places are open for " + p.name + "."
          : "Availability: volunteer places for " + p.name + " are currently full, so we will add you to the waiting list.");
      } else {
        if (p.cost === 0) {
          lines.push("Cost: this programme is free to join.");
        } else {
          lines.push("Estimated cost: " + money(qty * p.cost) + " (" + qty + " \u00d7 " + money(p.cost) + " per " + p.unit + ").");
        }
        lines.push(qty <= p.slotsLeft
          ? "Availability: " + p.slotsLeft + " places are left, so your request for " + qty + " fits."
          : "Availability: only " + p.slotsLeft + " places are left. We can confirm " + p.slotsLeft + " now and waitlist the other " + (qty - p.slotsLeft) + ".");
      }
      lines.push("Earliest start: " + prettyDate(start) + (preferred && preferred < earliest ? " (our next intake is later than your preferred date)." : "."));

      enquiryResponse.textContent = "";
      enquiryResponse.appendChild(make("h3", null, "Thank you, " + firstName + "!"));
      enquiryResponse.appendChild(make("p", null, "Here is an instant answer for " + p.name + ":"));
      var list = make("ul", { class: "response-list" });
      lines.forEach(function (line) { list.appendChild(make("li", null, line)); });
      enquiryResponse.appendChild(list);
      enquiryResponse.appendChild(make("p", { class: "form-note" }, "These figures are estimates. Our team will confirm the final details with you."));
      enquiryResponse.hidden = false;
      form.reset();
      clearErrors(form);
      quantityGroup.hidden = false;
      document.getElementById("message-count").textContent = "0 / " + form.elements.message.maxLength + " characters";
      enquiryResponse.focus();
      enquiryResponse.scrollIntoView({ behavior: motionOK ? "smooth" : "auto", block: "center" });
    }
  }

  /* --------------------------------------------------------
     11. CONTACT FORM (contact.html)
     After validation we compile the details into an email
     addressed to RECIPIENT (set at the top of this file) and
     let the visitor send it from their own email app.
     -------------------------------------------------------- */
  var contactForm = document.getElementById("contact-form");
  if (contactForm) {
    var emailPreview = document.getElementById("email-preview");
    addCounter(contactForm.elements.message);

    setupForm(contactForm, {
      fullName: nameError,
      email: emailError,
      phone: phoneError,
      type: requiredChoice("Please choose the type of message."),
      message: function (v) { return messageError(v, 20, 1000); }
    }, function (form) {
      var typeText = form.elements.type.options[form.elements.type.selectedIndex].text;
      var name = form.elements.fullName.value.trim();
      var subject = "[" + typeText + "] Message from " + name;
      var body = "Hello NEO PADS1 team,\n\n" + form.elements.message.value.trim() +
        "\n\n---\nName: " + name +
        "\nEmail: " + form.elements.email.value.trim() +
        "\nPhone: " + (form.elements.phone.value.trim() || "not provided") +
        "\nType of message: " + typeText;
      var mailto = "mailto:" + RECIPIENT + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);

      emailPreview.textContent = "";
      emailPreview.appendChild(make("h3", null, "Your email is ready"));
      emailPreview.appendChild(make("p", { class: "form-note" }, "Check it below, then press the button to send it from your email app."));
      emailPreview.appendChild(make("p", { class: "email-line" }, "To: " + RECIPIENT));
      emailPreview.appendChild(make("p", { class: "email-line" }, "Subject: " + subject));
      emailPreview.appendChild(make("pre", { class: "email-body" }, body));
      emailPreview.appendChild(make("a", { href: mailto, class: "btn btn-primary" }, "Send this email"));
      emailPreview.hidden = false;
      emailPreview.focus();
      emailPreview.scrollIntoView({ behavior: motionOK ? "smooth" : "auto", block: "center" });
    });
  }
});
